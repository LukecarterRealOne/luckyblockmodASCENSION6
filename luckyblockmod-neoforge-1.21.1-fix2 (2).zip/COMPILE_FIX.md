# NeoForge 1.21.1 compile fixes

This source revision addresses the compiler errors reported by the first GitHub Actions run and the additional error excerpt supplied in chat.

- Fixed ambiguous `Level.getEntities` usage with `getEntitiesOfClass(Entity.class, ...)`.
- Updated item max-stack-size access to use an `ItemStack`.
- Updated mob spawn initialization to the 1.21.1 four-argument `finalizeSpawn` signature.
- Updated `LargeFireball` construction to accept a direction `Vec3` and explosion power.
- Added `Fx.sound` overloads for both `SoundEvent` and `Holder<SoundEvent>` constants.
- Changed `setSecondsOnFire` calls to `setRemainingFireTicks`.
- Replaced removed `LivingAttackEvent` with `LivingIncomingDamageEvent`.
- Removed deleted `DistExecutor` references and used `IPayloadContext.enqueueWork` (plus a client-side guard for GUI opening).

Validation is static only. A complete Forge/NeoForge Gradle build must run in GitHub Actions to confirm the JAR compiles.


## Follow-up compile fix (NeoForge 1.21.1)

The next GitHub Actions compile reported seven errors in `Events.java` and `ClientEvents.java`.

- `Abilities.flyingSpeed` is private; all accesses now use `getFlyingSpeed()` and `setFlyingSpeed(float)`.
- `RenderGuiEvent.Post` does not expose `getWindow()` in NeoForge 1.21.1; GUI flash dimensions now come from `Minecraft.getInstance().getWindow()`.

These changes directly address the seven compiler errors in the supplied log. A fresh GitHub Actions run is still required to verify the entire project compiles.


## Compile Fix 3 (Java lambda capture)

The Lightning Storm delayed callback previously read the mutable loop variable `i`, which Java rejects when a local variable is captured by a lambda. The code now captures `i % 4 == 0` into the effectively-final `showScreenFlash` boolean before scheduling the callback. This preserves the intended every-fourth-strike flash behavior.
