package com.lucky.mod;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid = LuckyBlockMod.MOD_ID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        ClientState.tick();
        Minecraft mc = Minecraft.getInstance();
        while (ClientModEvents.OPEN_MENU.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new AbilityScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (ClientState.shakeTicks > 0) {
            float amp = ClientState.shakeAmp * ClientState.shakeTicks / ClientState.shakeMax;
            event.setYaw(event.getYaw() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
            event.setPitch(event.getPitch() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
            event.setRoll(event.getRoll() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
        }
    }

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        if (ClientState.flash <= 0.01f) return;
        int a = (int) (Math.min(1f, ClientState.flash) * 200);
        int argb = (a << 24) | (ClientState.flashColor & 0xFFFFFF);
        // RenderGuiEvent.Post no longer exposes a Window getter in NeoForge 1.21.1.
        // Read the active window from the client instance instead.
        Minecraft mc = Minecraft.getInstance();
        if (mc.getWindow() == null) return;
        event.getGuiGraphics().fill(0, 0, mc.getWindow().getGuiScaledWidth(),
                mc.getWindow().getGuiScaledHeight(), argb);
    }
}
